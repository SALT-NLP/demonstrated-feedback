This folder contains all discussion samples provided. Original sessions segmented to individual participants. Punctuation not inserted. Transcription marks removed.
New line for each turn

Participants renumbered 7/7/08 

Folder                 contains
-------------      -------------------------------------------------------------
Correlated         all discussions of (renumbered) participants 1-21
Extra              discussions of 3 replacement participants who did not complete entire correlated samples
                    replacement 3: did not supply phase I data
                    replacement 12: did not supply phase I data
                    replacement 16: did not complete phase I data 