This folder contains transcripts of chat groups, i.e., all particpants' contributions.  

Each group consisted of 4 participants.  Each transcript contains chat on 1 topic.
   (6 topics x 6 chat groups = 36 files)

Each partcipant is indentified by a "handle."
Transcription markings included.

No re-numbering of partcipants: numbering of Phase 2 participants (each prefixed by 'P') preserved. 

In Word format and plain text.
