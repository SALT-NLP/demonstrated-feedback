This folder contains all blog samples provided. Original punctuation and spelling preserved. Line breaks not inserted.
Multiple blog entries are concatenated to a single entry.

Participants renumbered 7/7/08 

Folder                 contains
-------------      -----------------------------------------------------
Correlated         all blogs of (renumbered) participants 1-21

Extra              blogs of 3 replacement participants who did not complete 
                                  entire correlated samples
                    Replacemnents were numbered 3, 12, and 16
