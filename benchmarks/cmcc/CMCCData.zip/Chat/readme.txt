This folder contains all chat samples provided. Original sessions segmented to individual participants. Original punctuation and spelling preserved. 
New line for each turn

Participants renumbered 7/7/08 

Folder                 contains
-------------      -------------------------------------------------------------------------
Correlated         all chats of (renumbered) participants 1-21  (6 x 21 = 126 files)

Extra              chats of 3 replacement participants who did not complete entire correlated samples
                    Replacements were numbered 3, 12, and 16.   (3 x 6 = 18 files)